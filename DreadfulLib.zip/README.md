Welcome to DreadfulLib, aka Bryn's Solution To Having To Call A Bunch Of Weird Stuff

Tools included are as follows:

-- Checking effects on player via score (support through 1.20.4 effects except Instant Damage/Health)